<div style="text-align:right;float:right">
    <div style="display:flex">
       <div style="margin-right:10px"></div>
        :عنوان العيادة
    </div>
</div>
