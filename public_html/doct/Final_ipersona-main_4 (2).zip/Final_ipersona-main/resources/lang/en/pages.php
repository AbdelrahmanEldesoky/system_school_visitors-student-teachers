<?php

return [
    'privacy_content' => "Thank you for using IPERSONA | We are very concerned about your trust in us.<br><br>

    We are committed to protecting the privacy and security of your information Personal The information you
    share with us helps us provide you with the best mental health services experience with IPERSONA's
    Privacy Policy refers to our privacy practices for all care services Psycho that we provide worldwide,
    and includes our privacy policy along with the terms of use rules and the general policies that govern
    your use of our site

    . Collection and use of personal information and data:<br><br>

    When requesting to communicate with us or wanting to obtain one of our services in the field of
    psychological care, we ask you to register your name, phone number, email, medical condition, and we
    will not use this information except for the purpose of providing psychological care services to you,
    however, you can register with an anonymous account.
    <br><br>
    How do we use your data? We do not collect any personal information related to you from any other source
    outside your use of the site or when you call the registered numbers, in addition to that we undertake
    not to share your personal information with any other party. When you register your personal data, we
    use it to continuously develop our services for you, or to inform you of all updates and news related to
    the site..
    <br><br>
    Data required to be obtained from you: The name phone number Medical condition e-mail We may also ask
    you to provide us with information about collecting payments from your credit card and after a
    transaction that we store this information (credit cards/Social Security numbers/data). financials, etc.
    on our servers)
    <br><br>

    Privacy policy related to the Internet only: The privacy policy includes the data and information that
    is collected It is collected only through the site and does not include any other means of
    communication.

    <br><br>
    How do we protect your personal data? Maintaining data privacy is very important to us more than it is
    important to you, and for this we provide electronic, physical guarantees and strict procedures designed
    specifically to preserve your data, ensuring that they are not Its access to the unauthorized, we use
    techniques, protocols, and electronic encryption to prevent leakage And transfer any personal
    information of yours to any other parties. You have the right to delete any data at any time when you
    wish. We provide the facility to use a secure server and all sensitive / affiliation information <br><br>
    submitted is sent via SSL technology is then registered in our payment gateway provider database so that
    the information is available only to individuals who are granted special access to these systems and who
    are required to They keep the information confidential. Our data is stored with a third-party provider
    that holds industry-recognized certifications and investigations, including the Payment Card Industry
    Data Security Standard Level 1, APRW 21001, the "Moderate Impact" standard of the Federal Information
    Security Management Act, the Federal Automated Risk Management and Authorization Program, and the
    Federal Information Security Administration Act. Health insurance transfer and accountability. and the <br><br>
    Audit Report for the Service Organization Controls previously referred to as the Statement of Audit
    Standards No. 10 and/or the Statement on the Standards for Certification Tasks and the Audit Report for
    the Controls of the Service Organization We also ensure that all Biananda is password protected and that
    data can be accessed through multiple authentication "Access to any data collected, as only agents and <br><br>
    not all members of the Ai Khair Sona team" individuals with specific roles are allowed to see the data
    being collected. collected when you store your data on our servers, we . They provide them with a <br><br>
    pseudonym and notation to maintain anonymity and provide an extra layer of security in the event of a
    burn for data.
    <br><br>
    How long we keep your data:
    <br><br>
    The criteria used to determine the period of storage of personal data is the relevant legal retention
    period. And after that space period. Corresponding data is routinely deleted for as long as it is no
    longer necessary for the use of our services. It only processes and stores your personal data for the
    period necessary to fulfill the purpose of storage and accordingly. If we have your email address
    because we provide certain services to you. We keep your email address for as long as we provide you <br><br>
    with these services. Basically your data is kept until your account is deleted. You can view the data it
    collects from you at any time, and you may request that we delete it at any time by accessing your
    account settings. A Cookie Policy Use of cookies is. Small files that the Website or its service
    provider transfers to your computer's hard drive through your web browser if you allow) that enable the <br><br>
    Website or its service provider's systems to recognize and remember your browser and certain information
    points. We use cookies to improve your experience for analytics and to show you offers tailored to your
    visits previous to our website You can choose to turn off all cookies by accessing your browser <br><br>
    settings. As with most websites, if you turn off cookies some of our services may not work in the right
    way.
    Non-Disclosure of Information to Third Parties We do not track, trade, or otherwise transfer your
    personally identifiable information to third parties. This does not include suspended third parties who
    assist us in operating our website, conducting our business, or providing you services, so long as those <br><br>
    parties have agreed to keep Confidentiality of this information We may also disclose your information
    when we believe that releasing it is consistent with the law, or for the purpose of complying with our <br><br>
    site policies, or to protect our rights or the rights or property of others or for marketing,
    advertising or other purposes.
    <br><br>
    All payment details and personally identifiable information will not be stored, sold, viewed or viewed
    by any third parties have her registered.
    <br><br>
    Disclosure regarding the Google Dicelity “Ad” platform that implements Google Analytics or “Google
    Analytics” features, which “use Teslay’s advertising information” to generate demographics and interests
    reports via the “Google Analytics” tool You can opt out of the Google Analytics tool for the Google <br><br>
    Display Ad platform to prevent your data from being used. With Google Analytics. This is done by going
    to the Google Analytics opt-out page. First party cookies are used, along with third party vendors <br><br>
    (including Google). (such as Google Analytics cookies) and third-party cookies (such as DoubleClick
    cookies) to inform how ad impressions and other uses of ad services and interactions with ad impressions
    and ad services are related to visiting our website. You can read more about cookies Cookie used by <br><br>
    Google Analytics Advertising Features" by going to the "Privacy Policy" page of the "Google Analytics"
    platform
    <br><br>
    Third-Party Links: We may include or offer products or services provided by a third party on our
    website. Third-party sites have separate and independent privacy policies, and therefore we do not <br><br>
    assume any responsibility or liability for the content and content of these linked sites. However, we
    seek to protect the integrity of our site, and we welcome any feedback or complications about those <br><br>
    sites and strongly advise you to review our privacy policy and terms. and the terms contained on each
    website that you visit
    <br><br>
    Your rights:
    <br><br>
    You have the right to obtain confirmation as to whether or not your personal data is being processed.
    You can contact us at any time to claim this right.
    <br><br>You have the right to request information that we are currently processing.
    <br><br>You can also request the following for the purposes of processing the categories of personal
    data concerned and the recipients or categories of recipients to whom the personal data has been or will <br><br>
    be disclosed, in particular the recipients located in third countries or international organisations,
    and the intended period during which the personal data will be stored, where possible that, or the
    criteria used to determine that period if this is not possible and the right to request correction or
    erasure of personal data from the controller, restriction of processing of personal data relating to the
    data subject or object to the data processing and the right to lodge a complaint with a supervisory body <br><br>
    and in the event of failure to collect Personal data from the data subject, and any information
    available from its source You have the right to inform us of a change in your information, and when the
    information we have on file is no longer accurate. In consideration of the purposes of the processing,
    you have the right to complete incomplete personal data, including by providing a supplementary
    statement. You have every right to request the erasure of personal data without undue delay.. You have <br><br>
    the right to receive personal data relating to you provided to the controller in a structured, commonly
    used and machine-readable format You have the right to object, at any time, to the processing of your
    personal data.
    We will not process personal data where you object to this, unless we have legitimate and compelling
    reasons to process the data that would obscure your interests, rights and freedoms, or to initiate, <br><br>
    exercise or defend legal claims. You have the right to withdraw your consent to the processing of your
    personal data at any time
    Terms of use Please see the terms of use that set out the use, disclaimers and limitations by visiting
    the following link ipersona.me. <br><br>
    Responsibility governing the use of our website. Your consent: You agree to our privacy policy when
    visiting our website. The terms of use and privacy policy contained in the website may be changed or
    updated from time to time to meet legal requirements and standards. Therefore, we would like you to <br><br>
    visit these sections frequently in order to be aware of changes that are made on the site. Amendments
    are effective on the day they are posted Contacting us If you have any questions regarding the privacy
    policy, you can contact us by mail email at the following address info@ipersona.me",



];

?>
