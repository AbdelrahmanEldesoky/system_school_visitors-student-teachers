<?php
return[
'homw'=>'Hospitals',
'brief'=>'The ipersona platform is a contractor with the best mental health and addiction treatment hospitals in Egypt and the Arab world .',
''=>'',
''=>'',
''=>'',
''=>'',
''=>'',
''=>'',
''=>'',
];

