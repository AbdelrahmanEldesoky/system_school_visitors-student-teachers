<?php

return [
    'detail' => "iPersona is the leading online healthcare platform for doctor booking and clinic management organization software in the Middle East and North Africa region. We are driving the electronic and automated transformation of doctors, clinics and hospitals to make high-quality healthcare accessible in the Arab region",
    'Copyright'=>'Copyright',
    'Need_Info'=>'Need Info?',
    'subscribe_newsletter'=>'Subscribe to our newsletter',
    'subscribe_detail'=>'You will get best updates from us only. Dont worry we will not irritate you with spam mails or burden of inbox...',
    'follow'=>'Follow us on social media:',
    'reserved'=>'All Rights Reserved.',
];

?>
