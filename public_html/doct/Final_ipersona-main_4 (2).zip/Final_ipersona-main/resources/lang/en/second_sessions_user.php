<?php
return[
'name'=>'Name',
'sessio_link'=>'Session link',
'today'=>'Today',
'history'=>'History',
'watch'=>'Watch',
'home'=>'My sessions',
'brief'=>'You can now follow all your sessions and review them at any time and whenever you want with ease on the ipersona platform',
''=>'',
''=>'',
''=>'',
''=>'',
''=>'',
''=>'',
''=>'',   
];