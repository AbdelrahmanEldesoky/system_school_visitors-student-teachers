<?php

return[
    'name'=>'User Nmae',
    'email'=>'Email',
    'gender'=>'Gender',
    'phone'=>'Phone',
    'country'=>'Country',
    'password'=>'Password ',
    'confirm_password'=>'Confirm Password  ',
    'sign_in'=>'Sign in ',
    'registration'=>' registration ',
    'change_theme'=>'change_theme ',
    'male'=>'Male',
'female'=>'Female',
'egypt'=>'Egypt',
'algeria'=>'Algeria',
'kuwait'=>'Kuwait',
'morocco'=>'Morocco',
'create_account'=>'Create account',
'already_account'=>'Already have an account ?',
'login_to_see'=>'Log in to see your sessions and contact your doctor',
'i_accept_the'=>'I accept the',
'terms_and_services'=>'terms and services',
'have_account'=>'You don,t have an account?',
'create_your_account'=>'Create your account now to follow sessions in class',
'edit' => 'Edir profile',
'footer'=>' حقوق النشر . جميع الحقوق محفوظة',
'ipersona'=>'Ipersona',
// error
'error_name'=>'input name is required',
'error_email'=>'input email is required',
'error_gender'=>'input gender is required',
'error_phone'=>'input phone is required',
'error_country'=>'input country is required',
'error_password'=>'input password is required',
'error_conferm_password'=>'input conferm passwordder is required',

'name.required' => 'The name field is required',
'name.string' => 'The name field must be a string',
'name.max' => 'The name field must be less than 255 characters',
'name.min' => 'The name field must be more than 3 characters',

'email.required' => 'The email field is required',
'email.string' => 'The email field must be a string',
'email.email' => 'The email field is not valid',
'email.max' => 'The email field is too large',
'email.unique' => 'We already have this mail',

'password.required' => 'The password field is required',
'password.min' => 'The password field must be more than 6 characters',
'password.confirmed' => 'The password does not match the confirm password',

'phone.required' => 'The phone field is required',



];
